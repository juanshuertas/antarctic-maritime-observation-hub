# AMOH - HUB DE OBSERVACIÓN MARÍTIMA ANTÁRTICA
## Paquete de Datos: Pozos Offshore y Minería Submarina Austral / Antártica
**Fecha de Generación:** 2026-09-23 00:59:04  
**Sistema de Referencia Espacial:** WGS 84 (EPSG:4326)

---

### 📦 Contenido del Paquete de Descarga:

1. **`offshore_wells.geojson`** & **`offshore_wells.csv`**:
   - 15 pozos y plataformas offshore georreferenciados.
   - Incluye complejos gasíferos de Cuenca Marina Austral (CMA-1: Fénix, Vega Pléyade, Carina-Aries, Poseidón, Spiteful).
   - Pozos descubridores y exploratorios de Cuencas Malvinas (Sea Lion, Darwin East, Isobel Deep, Toroa).
   - Sondeos científicos profundos polares (DSDP Sites 271/272 Mar de Ross, ODP Sites 692/693 Mar de Weddell, ODP Site 741 Bahía Prydz, ANDRILL McMurdo).

2. **`deepsea_mining.geojson`** & **`deepsea_mining.csv`**:
   - 11 campos hidrotermales, yacimientos SMS y depósitos abisales polares.
   - Sulfuros Masivos Polimetálicos (SMS) & Chimeneas Black Smokers (East Scotia Ridge E2/E9, Caldera Kemp, Hook Ridge, Three Sisters, Dorsal Pacífico-Antártica PAR-1, Discordancia Australo-Antártica AAD).
   - Pavimentos de Nódulos Polimetálicos de Manganeso (Cuenca de Bellingshausen, Jane Basin en Mar de Weddell, Meseta de Kerguelen).
   - Costras de Ferromanganeso Ricas en Cobalto (Banco Burwood / Arco de Scotia).

3. **`pozos_y_mineria_combinada.geojson`** & **`pozos_y_mineria_combinada.csv`**:
   - Dataset unificado con todos los puntos para fácil importación en SIG y análisis de datos.

---

### ⚖️ Marco Legal y Tratados Internacionales:
- **Al sur del paralelo 60°S**: Rige el **Artículo 7 del Protocolo de Madrid al Tratado Antártico** (moratoria absoluta a cualquier explotación minera o energética comercial; reserva dedicada a la ciencia y la paz).
- **Al norte del paralelo 60°S**: Aguas internacionales y fondos abisales bajo la **Autoridad Internacional de los Fondos Marinos (ISA)** y la **CONVEMAR**, o bajo jurisdicción de las plataformas continentales / ZEE de Estados ribereños.

---

### 🛠️ Cómo Importar en Herramientas SIG / Análisis:
- **QGIS / ArcGIS Pro**: Arrastre directamente los archivos `.geojson` o importe el `.csv` (usando `longitude` como campo X y `latitude` como campo Y en EPSG:4326).
- **Python / GeoPandas**:
```python
import geopandas as gpd
gdf_wells = gpd.read_file("offshore_wells.geojson")
gdf_mining = gpd.read_file("deepsea_mining.geojson")
print(gdf_wells[["name", "operator", "water_depth_m"]])
print(gdf_mining[["name", "minerals", "regulatory_regime"]])
```
